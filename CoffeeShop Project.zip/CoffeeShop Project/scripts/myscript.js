var addCart = document.getElementById('addtocartbutton1');
addCart.onclick = function() {
    alert("Item added to cart!");
}